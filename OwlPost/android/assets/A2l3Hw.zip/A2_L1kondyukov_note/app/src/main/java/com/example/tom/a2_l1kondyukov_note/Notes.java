package com.example.tom.a2_l1kondyukov_note;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Tom on 14.01.2018.
 */

public class Notes {
    private static Notes instance;
    private List<Note> noteList;
    private int check;
    private String city = "Moscow,RU";


    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public static Notes getInstance(){
        if (instance == null){
            instance = new Notes();
            return instance;
        }else {
            return instance;
        }
    }

    private Notes() {
        this.noteList = noteList;
        noteList = new ArrayList<>();
        notesAdd(new Note("Заметка 1", "Введите текст заметки"));
        notesAdd(new Note("Заметка 2", "Введите текст заметки"));
        notesAdd(new Note("Заметка 3", "Введите текст заметки"));
    }

    public void notesAdd (Note note){
        noteList.add(note);
    }

    public void removeNote (){
        noteList.remove(check);
    }

    public List<Note> getNoteList() {
        return noteList;
    }

    public void setCheck(int check) {
        this.check = check;
    }

    public int getCheck() {
        return check;
    }
}
