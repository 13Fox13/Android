package com.example.tom.a2_l1kondyukov_note;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class PageFragment extends android.support.v4.app.Fragment {
    private Button saveButton;
    private EditText tittle;
    private EditText page;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        assert container != null;
        View root = LayoutInflater.from(container.getContext()).inflate(R.layout.fragment_page, container, false);
        saveButton = root.findViewById(R.id.fragment_save_button);
        tittle = root.findViewById(R.id.fragment_tittle);
        tittle.setText(Notes.getInstance().getNoteList().get(Notes.getInstance().getCheck()).getTittle());
        page = root.findViewById(R.id.fragment_note);
        page.setText(Notes.getInstance().getNoteList().get(Notes.getInstance().getCheck()).getPage());
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Notes.getInstance().getNoteList().get(Notes.getInstance().getCheck()).setTittle(tittle.getText().toString());
                Notes.getInstance().getNoteList().get(Notes.getInstance().getCheck()).setPage(page.getText().toString());
                ((MainActivity)getActivity()).reCreateAdapter();
                getActivity().getSupportFragmentManager().beginTransaction().remove(PageFragment.this).commit();
            }
        });
        return root;
    }
}
