package com.example.tom.a2_l1kondyukov_note;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.Intent;
import android.os.Handler;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import static com.example.tom.a2_l1kondyukov_note.Notes.getInstance;

public class MainActivity extends AppCompatActivity {
    private ListView note;
    private PageFragment pageFragment;
    private FragmentManager fragmentManager;
    private ArrayList<String> arrayList;
    private ArrayAdapter<String> adapter;
    private TextView emptyText;
    private final Handler handler = new Handler();
    private TextView cityTextView;
    private TextView detailsTextView;
    private TextView currentTemperatureTextView;
    private Button changeCityButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cityTextView = findViewById(R.id.city_field);
        detailsTextView = findViewById(R.id.details_field);
        currentTemperatureTextView = findViewById(R.id.current_temperature_field);

        reDrawWeather();
        changeCityButton = findViewById(R.id.change_city_button);
        changeCityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager manager = getSupportFragmentManager();
                ChoseCityDialogFragment choseCityDialogFragment = new ChoseCityDialogFragment();
                choseCityDialogFragment.show(manager, "dialog");
            }
        });
        note = findViewById(R.id.note_list);
        emptyText = findViewById(R.id.empty_text);
        arrayList = new ArrayList<String>();
        for (int i = 0; i < getInstance().getNoteList().size(); i++) {
            arrayList.add(getInstance().getNoteList().get(i).getTittle());
        }
        adapter = new ArrayAdapter<String>(this, R.layout.list_item, arrayList);
        note.setAdapter(adapter);
        registerForContextMenu(note);

        if (getInstance().getNoteList().size() == 0) {
            emptyText.setVisibility(TextView.VISIBLE);
        } else {
            emptyText.setVisibility(TextView.INVISIBLE);
        }

        fragmentManager = getSupportFragmentManager();

        note.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                adapter.clear();
                getInstance().setCheck(i);
                pageFragment = new PageFragment();
                fragmentManager.beginTransaction().add(R.id.cont, pageFragment).commit();
            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.menu_create: {
                pageFragment = new PageFragment();
                emptyText.setVisibility(TextView.INVISIBLE);
                reCreateAdapter();
                getInstance().setCheck(getInstance().getNoteList().size());
                getInstance().notesAdd(new Note("Заметка " + (getInstance().getNoteList().size() + 1), "Введите текст заметки"));
                this.adapter.clear();
                fragmentManager.beginTransaction().add(R.id.cont, pageFragment).commit();
                return true;
            }
        }
        return true;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        getMenuInflater().inflate(R.menu.contex, menu);
        AdapterView.AdapterContextMenuInfo acmi = (AdapterView.AdapterContextMenuInfo) menuInfo;
        Notes.getInstance().setCheck(acmi.position);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case R.id.menu_delete: {
                Notes.getInstance().removeNote();
                arrayList.clear();
                reCreateAdapter();
                if (arrayList.size() == 0) {
                    emptyText.setVisibility(TextView.VISIBLE);
                }
                return true;
            }
            case R.id.menu_edit: {
                adapter.clear();
                pageFragment = new PageFragment();
                fragmentManager.beginTransaction().add(R.id.cont, pageFragment).commit();
                return true;
            }
        }
        return true;
    }

    public void reCreateAdapter() {
        note.setAdapter(adapter);
        Notes.getInstance().setCheck(note.getSelectedItemPosition());
        for (int i = 0; i < getInstance().getNoteList().size(); i++) {
            arrayList.add(getInstance().getNoteList().get(i).getTittle());
        }
        adapter = new ArrayAdapter<String>(getApplicationContext(), R.layout.list_item, arrayList);
        note.setAdapter(adapter);
    }


    private void updateWeatherData(final String city) {
        new Thread() {
            public void run() {
                final JSONObject json = WeatherDataLoader.getJSONData(getApplicationContext(), city);
                if (json == null) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(), "City not found", Toast.LENGTH_LONG).show();
                        }
                    });
                } else {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            renderWeather(json);
                        }
                    });
                }
            }
        }.start();
    }


    @SuppressLint("SetTextI18n")
    private void renderWeather(JSONObject json) {
        try {
            cityTextView.setText(json.getString("name").toUpperCase(Locale.US) + ", "
                    + json.getJSONObject("sys").getString("country"));

            JSONObject details = json.getJSONArray("weather").getJSONObject(0);
            JSONObject main = json.getJSONObject("main");


            detailsTextView.setText(details.getString("description").toUpperCase(Locale.US) + "\n" + "Влажность: "
                    + main.getString("humidity") + "%" + "\n" + "Давление: " + main.getString("pressure") + " hPa");

            currentTemperatureTextView.setText(String.format("%.2f", main.getDouble("temp")) + " ℃");

        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Ошибка", Toast.LENGTH_LONG).show();
        }
    }

    public void reDrawWeather() {
        updateWeatherData(Notes.getInstance().getCity());
    }

}

