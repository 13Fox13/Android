package com.example.tom.a2_l1kondyukov_note;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AlertDialog;

/**
 * Created by vgs_kinoeng on 19.01.2018.
 */

public class ChoseCityDialogFragment extends DialogFragment {
    private final String [] cityArray = {"Moscow,RU", "Paris", "London","Tokyo","Mexico", "Cairo"};

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Выберите город").setItems(cityArray, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
             Notes.getInstance().setCity(cityArray[i]);
                ((MainActivity)getActivity()).reDrawWeather();
            }
        });
        return builder.create();
    }
}
