package com.example.tom.a2_l1kondyukov_note;

/**
 * Created by Tom on 14.01.2018.
 */

public class Note {
    private String tittle;
    private String page;

    public Note(String tittle, String page) {
        this.tittle = tittle;
        this.page = page;
    }

    public String getTittle() {
        return tittle;
    }

    public void setTittle(String tittle) {
        this.tittle = tittle;
    }

    public String getPage() {
        return page;
    }

    public void setPage(String page) {
        this.page = page;
    }
}
